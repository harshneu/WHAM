package com.neu.wham.exceptions;

public class RegistrationFailedException extends Exception{
	public RegistrationFailedException(String msg) {
		super(msg);
	}
}
