package com.neu.wham.services;

public interface LookupService {
	public String lookup(String location);
}
