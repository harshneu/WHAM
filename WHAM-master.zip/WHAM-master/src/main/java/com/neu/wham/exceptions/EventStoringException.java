package com.neu.wham.exceptions;

public class EventStoringException extends Exception{
	public EventStoringException(String msg) {
		super(msg);
	}
}
