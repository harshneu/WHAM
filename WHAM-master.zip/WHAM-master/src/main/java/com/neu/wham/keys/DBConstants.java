package com.neu.wham.keys;

public class DBConstants {
	// JDBC driver name and database URL
	public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	public static final String DB_URL = "jdbc:mysql://ec2-52-87-159-69.compute-1.amazonaws.com:3306/whamDB";
	//  Database credentials
	public static final String USER = "wham";
	public static final String PASS = "wham@123";
}
