package com.neu.wham.keys;

/**
 * Keys used for google location api & event brite api
 * @author Vijet Badigannavar
 * @author AswinMuthiah
 */
public class Keys {
	/**
	 * GEO-coding google API key
	 */
	public static final String GEO_CODING_API_KEY = "AIzaSyBwWpjQxVoS8mubA3u9q820O8nYV-ClfFc";
	public static final String EVENTBRITE_KEY = "DXVHSQKC2T2GGBTUPOY2";
}
